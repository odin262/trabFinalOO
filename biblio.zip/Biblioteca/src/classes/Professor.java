package classes;

public class Professor extends Cliente {
	
	public String cpf;

}
