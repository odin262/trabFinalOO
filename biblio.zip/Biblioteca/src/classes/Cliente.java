package classes;

import javax.swing.JOptionPane; 


public class Cliente {
	
	public int id;
    public String nome, telefone;
    public String endereco;
    public String email;
    public Aluno aluno;
    
 public Cliente() {
        
    }
    
   
    public Cliente(String nome){
        this.nome = nome;
    }
    
    public Cliente(int id, String nome){
        this.id = id;
        this.nome = nome;
    }
    
    public void imprimir(){
        String texto = "Nome: " + this.nome + "\nTelefone: " + this.telefone;
        JOptionPane.showMessageDialog(null, texto);
    }
    
    private void imprimirEmail(){
        String texto = "Email: " + this.email ;
        JOptionPane.showMessageDialog(null, texto);
    }
   

}
