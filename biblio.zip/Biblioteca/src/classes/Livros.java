package classes;

import classes.Categoria;

public class Livros {
	
	public int id;
	public String titulo;
    public Categoria categoria;
    public String autor;

}
