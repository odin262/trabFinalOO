package classes;

import javax.swing.JOptionPane;

public class Aluno extends Cliente{
	
	public int id;
	public String matricula;
	
	 /*public Aluno1() {
	    }*/
	
	 public Aluno(){
	        super();
	    }
	    public Aluno(int id) {
	        this.id= id;
	    }

	    public Aluno(String nome) {
	        super(nome);
	    }
	    
	   /* public int getId() {
	        return id;
	    }

	    public void setId(int id) {
	        this.id = id;
	    }

	    public String getMatricula(){
	        return matricula;
	    }

	    public void setMatricula(String matricula) {
	        this.matricula = matricula;
	    }*/


	    @Override
	    public void imprimir() {
	        String texto = "Nome: " + this.nome + "\nTelefone: " + this.telefone + 
	                "\nMatricula: " + this.matricula;
	        JOptionPane.showMessageDialog(null, texto);
	      
	        
	    }

}
