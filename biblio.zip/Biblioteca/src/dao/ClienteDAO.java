package dao;

import java.sql.ResultSet;  
import java.util.ArrayList;
import java.util.List;

import classes.Aluno;
//import classes.Categoria;
import classes.Cliente;

public class ClienteDAO {
	
	 public static void inserir( Cliente cliente ){
	        String query = "INSERT INTO livro (id, nome, telefone, endereco, email) VALUES ( "
	                    // + " '" + cliente.id +  "' , "
	                     + "  " + cliente.nome + " ,  "
	                     + "  " + cliente.telefone + " ,  "
	                     + "  " + cliente.endereco + " ,  "
	                     + "  " + cliente.email + "   ) ";
	        
	        Conexao.executar( query );
	    }
	    
	    public static void editar( Cliente cliente ){
	        String query = "UPDATE livro SET "
	                     + " nome = '" + cliente.nome +  "' , "
	                     + " telefone = " + cliente.telefone + " ,  "
	                     + " endereco = '" + cliente.endereco +  " , "
	                     + " nome = '" + cliente.email +  "  "
	                     + " WHERE id = " + cliente.id ;
	        
	        Conexao.executar( query );  
	    }
	    
	    
	    public static void excluir( int id ){
	        String query = "DELETE cliente WHERE id = " + id ;
	        
	        Conexao.executar( query );  
	    }
	    
	    public static List<Cliente> getcliente(){
	        List<Cliente> listaDeCliente = new ArrayList<>();
	        
	        String query = "SELECT c.Id_cliente , c.nome, c.telefone, c.endereco, c.email, a.matricula" // SELECT * from cliente;
	                   + " FROM cliente c "
	                   + " INNER JOIN aluno a ON a.idAluno = c.id_cliente "
	                   + " ORDER BY c.nome ";
	        
	       /* String query = "SELECT c.id , c.nome, c.telefone, c.endereco, c.email, p.cpf" // SELECT * from cliente;
	                   + " FROM cliente c "
	                   + " INNER JOIN professor p ON p.idCPF = c.id_cliente "
	                   + " ORDER BY l.nome "; */
	        
	        ResultSet rs = Conexao.consultar( query );
	        
	        if( rs != null ){
	            
	            try{
	                while( rs.next() ){
	                    
	                    Cliente cliente = new Cliente();
	                    cliente.id = rs.getInt( 1 );
	                    cliente.nome = rs.getString( 2 ) ;
	                    cliente.telefone = rs.getString( 3 ) ;
	                    cliente.endereco = rs.getString( 4 ) ;
	                    cliente.email = rs.getString( 5 ) ;
	                    
	                    Aluno alu = new Aluno( rs.getInt(4));
	                    
	                    cliente.aluno = alu;
	                    
	                    listaDeCliente.add( cliente );
	                }
	                
	            }catch(Exception e){
	                
	            }
	        }
	        return listaDeCliente;
	    }
	    
	    
	    
	    
	}



