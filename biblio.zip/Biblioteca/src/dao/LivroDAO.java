package dao;

import java.sql.ResultSet ;
import java.util.ArrayList;
import java.util.List;
import classes.Categoria;
import classes.Livros;

public class LivroDAO {
    
    public static void inserir( Livros livro ){
        String query = "INSERT INTO livro (titulo, autor, codCategoria) VALUES ( "
                     + " '" + livro.titulo +  "' , "
                     + "  " + livro.autor + " ,  "
                     + "  " + livro.categoria.id + "   ) ";
        
        Conexao.executar( query );
    }
    
    public static void editar( Livros livro ){
        String query = "UPDATE livro SET "
                     + " nome = '" + livro.titulo +  "' , "
                     + " autor = " + livro.autor + "   "
                     + " WHERE id = " + livro.id ;
        
        Conexao.executar( query );  
    }
    
    
    public static void excluir( int idLivro ){
        String query = "DELETE livro WHERE id = " + idLivro ;
        
        Conexao.executar( query );  
    }
    
    public static List<Livros> getLivros(){
        List<Livros> listaDeLivros = new ArrayList<>();
        
        String query = "SELECT l.id , l.titulo, l.autor, c.id, c.nome "
                    + " FROM livros l "
                    + " INNER JOIN categorias c ON c.id = l.codCategoria "
                    + " ORDER BY l.nome ";
        
        ResultSet rs = Conexao.consultar( query );
        
        if( rs != null ){
            
            try{
                while( rs.next() ){
                    
                    Livros livro = new Livros();
                    livro.id = rs.getInt( 1 );
                    livro.titulo = rs.getString( 2 ) ;
                    livro.autor = rs.getString( 3 ) ;
                    
                    Categoria cat = new Categoria( rs.getInt(4) , rs.getString(5));
                    
                    livro.categoria = cat;
                    
                    listaDeLivros.add( livro );
                }
                
            }catch(Exception e){
                
            }
        }
        return listaDeLivros;
    }
    
    
    
    
}
