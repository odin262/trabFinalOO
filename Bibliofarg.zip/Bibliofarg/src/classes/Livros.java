package classes;

public class Livros {

	public int id;
	public String titulo, autor;
    public Categoria categoria;
    
}
